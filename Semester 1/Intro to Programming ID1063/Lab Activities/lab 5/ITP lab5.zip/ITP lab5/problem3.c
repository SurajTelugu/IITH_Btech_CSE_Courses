#include<stdio.h>
#include<stdlib.h>
#define numofletters 30
int main()

{
  char c[numofletters];
  int n=1,i,j,r,x;
  printf("this program rotates the letters in word by r times r value entered by user\n \n");
  printf("enter the word:");
  scanf("%s",c);
  printf("enter the number of rotations r:");
  scanf("%d",&r);

  for(i=1;c[i]!='\0';i++) {n++;}

  for(i=1;i<=r;i++)
  {
    x=c[0];
    
    for(j=0;j<n;j++)
    {
      c[j]=c[j+1];
    }

    c[n-1]=x;
  }

  printf("after the rotation of letters in the word the word changes to %s\n",c);

  /*program ends*/

 return EXIT_SUCCESS;
}