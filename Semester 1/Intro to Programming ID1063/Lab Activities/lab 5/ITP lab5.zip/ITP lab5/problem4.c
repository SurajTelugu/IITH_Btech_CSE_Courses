#include<stdio.h>
#include<stdlib.h> 
int main()

{
  int l,b,i,j;
  printf("enter the length of rectangle:");
  scanf("%d",&l);
  printf("enter the breadth of rectangle:");
  scanf("%d",&b);

  for(i=1;i<=m;i++)
  {
    for(j=1;j<=b;j++)
    {
      if(i==1||i==l||j==1||j==b) printf("*");
      else printf(" ");
    }
    printf("\n");
  }
 return EXIT_SUCCESS;
}