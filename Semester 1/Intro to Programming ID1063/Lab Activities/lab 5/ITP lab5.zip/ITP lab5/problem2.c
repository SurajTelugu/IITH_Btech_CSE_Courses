#include<stdio.h>
#include<stdlib.h>
#define number 6
int main()

{
  int num[number],i,max,min;
  printf("this program prints the max and min value of given set of integers\n\n ");

  for(i=0;i<number;i++)
  {
    printf("enter the integer:");
    scanf("%d",&num[i]);
  }
  printf("\n");

  max=num[0];

  for(i=1;i<number;i++)
  {
    if(max<num[i])
    max=num[i];
  }

  printf("the maximum of given set of integers:%d\n",max);

  min=num[0];

  for(i=1;i<number;i++)
  {
    if(min>num[i])
    min=num[i];
  }

  printf("the minimum of given set of integers:%d\n",min);

  

 return EXIT_SUCCESS;
}