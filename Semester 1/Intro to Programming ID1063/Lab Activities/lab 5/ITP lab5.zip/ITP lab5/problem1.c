#include<stdio.h>
#include<stdlib.h>
#define numofletters 30
int main()

{
 
  char alpha[numofletters];
  printf("this program counts number of vowels and letters of given word\n");
  printf("enter the word whose number of letters and vowels need to be counted:\n");
  scanf("%s",alpha);

  int x,n=0,a=0,e=0,i=0,o=0,u=0;
  for(x=0;alpha[x]!='\0';x++)
  {
    if(alpha[x]=='a'||alpha[x]=='A') {a++;}
    if(alpha[x]=='e'||alpha[x]=='E') {e++;}
    if(alpha[x]=='i'||alpha[x]=='I') {i++;}
    if(alpha[x]=='o'||alpha[x]=='O') {o++;}
    if(alpha[x]=='u'||alpha[x]=='U') {u++;}
    n++;
  }

  printf("the string length is %d\n",n);
  printf("the number of vowels a or A in the word is %d\n",a);
  printf("the number of vowels e or E in the word is %d\n",e);
  printf("the number of vowels i or I in the word is %d\n",i);
  printf("the number of vowels o or O in the word is %d\n",o);
  printf("the number of vowels u or U in the word is %d\n",u);
  /*program ends*/
  
  return EXIT_SUCCESS;
}