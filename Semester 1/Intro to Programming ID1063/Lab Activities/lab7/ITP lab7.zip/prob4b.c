#include<stdio.h>
#include<stdlib.h> 

double fallfact(double x,unsigned int n)
{
  double fact_num=x; int i;
  for(i=1;i<n;i++)
  {
    fact_num=fact_num*(x-i);
  }
  return fact_num;
}

unsigned int factorial(unsigned int n)
{
  int i; unsigned int funcfact=1;
  for(i=0;i<n;i++)
  {funcfact=funcfact*(n-i);}
  return funcfact;
}

double realbinomialcoefficient(double x,unsigned int n)
{
  double p=fallfact(x,n);
  unsigned int q=factorial(n);
  return p/q;
}

int main()
{
  printf("This program finds the Real Binomial Coefficient of x upto n numbers(xCn)\n\n");
  unsigned int n; double x;
  printf("Enter the value of X whose Real Binomial Coefficient is needed:");
  scanf("%lf",&x);
  printf("Enter positive integer n for:");
  scanf("%u",&n);
  printf("\n");

  printf("The value of Real Binomial Coefficient for given X,n is:%lf",realbinomialcoefficient(x,n));
  printf("\n");

/*program ends*/ 
 return EXIT_SUCCESS;
}