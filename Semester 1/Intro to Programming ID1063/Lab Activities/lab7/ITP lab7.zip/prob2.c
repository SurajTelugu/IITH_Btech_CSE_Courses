#include<stdio.h>
#include <stdlib.h>
unsigned int num_times_string(char text[],unsigned int num)
{
    unsigned int i=1;
    while (i<=num)
    {
      printf("%s\n",text);
        i=i+1;
    }
    return i;
}

void substring(char text[],unsigned int i,unsigned int j)
{
    unsigned int a;
    for(a=i;a<=j;a++)
    putchar(text[a]);
    }


int main()
{
  printf("This program repeats word for given number of times and gives substring of given string of a count from ith letter to jth letter\n\n");
 
  char string[20]="Applesauce"; int i,j,k,count;
  
  printf("enter the count of string(number of times word should repeat):");
  scanf("%d",&count);
  num_times_string(string,count);
  printf("\n");

  printf("Enter the value of i:");
  scanf("%d",&i);
  printf("Enter the value of j:");
  scanf("%d",&j);
  printf("\n");

  printf("the sub string of the string is: ");
  substring(string,i, j);
  printf("\n");
 
   /*program ends*/
    return EXIT_SUCCESS;
}

