#include<stdio.h>
#include<stdlib.h>
int main()
{
 int n,m;
 printf("this program prints the dot product of vector and matrix\n(i.e dot product of nxn matrix and nx1 matrix[vector])\n\n");

 printf("the order of matrix you choose\n(note:no of dimentions of vector automatically chosen):");
 scanf("%d",&n);
 printf("\n");

  float mat[n][n]; int i,j;
  for(i=1;i<=n;i++)
  {
    for(j=1;j<=n;j++)
    {
      printf("enter a%d%d th element:",i,j);
      scanf("%f",&mat[i][j]);
    }
  }
  printf("the matrix is:\n"); 
  for (i=1; i<= n; i++)
    {
        for (j=1; j<=n; j++)
        {
            printf("%f\t", mat[i][j]);
        }
        printf("\n");
    }

    printf("\n");

  float vect[n];
  for(i=1;i<=n;i++)
  {
    printf("enter %d dimentional element of vector:",i);
    scanf("%f",&vect[i]);
  }
  printf("the vector is: \n");
   for (i = 1; i<= n; i++)
        {
            printf("%f\t", vect[i]);
        }

float finalmat[n],sum;
  for(i=1;i<=n;i++)
  {
    for(j=1;j<=n;j++)
    {
      sum=0;
      sum=vect[i]*mat[i][j];
      finalmat[i]=sum+finalmat[i];
    }
  }

  printf("\n\n");
  printf("the final matrix (the dot product of Matrix and vector) is:\n"); 
  for (i=1; i<= n; i++)
    { printf("%f\t", finalmat[i]);}
  printf("\n");
  /*program ends*/
  return EXIT_SUCCESS;
}