#include<stdio.h>
#include<stdlib.h> 

double fallfact(double x,unsigned int n)
{
  double fact_num=x; int i;
  for(i=1;i<n;i++)
  {
    fact_num=fact_num*(x-i);
  }
  return fact_num;
}

int main()
{
  printf("This program finds the Falling Factorial of x upto n numbers\n\n");
  unsigned int n; double x;
  printf("Enter the value of X whose Falling Factorial is needed:");
  scanf("%lf",&x);
  printf("Enter positive integer n upto where Falling Factorial is needed:");
  scanf("%u",&n);
  printf("\n");
  printf("The Falling Factorial of X is:%lf\n",fallfact(x,n));

/*program ends*/ 
 return EXIT_SUCCESS;
}