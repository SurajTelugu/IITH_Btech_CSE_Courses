#include<stdio.h>
#include<stdlib.h> 

double array_num(double a[],int i,int j)
{
  double sum=0; int k;
  for(k=i;k<=j;k++)
  {
    sum=sum+a[k];
  }
  return sum;
}

int main()
{
  printf("For a given Array this program adds ith element of array upto jth element (both included)\n\n");

  int n,a;
  printf("Enter the size of array:");
  scanf("%d",&n);

  double alpha[n];/*let alpha be the array user has to enter*/
  for(a=1;a<=n;a++)
  {
    printf("Enter the  element number%d of array:",a);
    scanf("%lf",&alpha[a]);
  }
  printf("\n");
  int i,j;

  printf("Enter the value of i:");
  scanf("%d",&i);
  printf("Enter the value of j:");
  scanf("%d",&j);
  printf("\n");
  
  if(i<=n&&j<=n)
 {
 printf("the sum of all elements from element number%d to element number%d in your array is:%lf\n",i,j,array_num(alpha,i,j));}
 else 
 {
   printf("entered values of i and j are out of bound\n");
 }
 /*program ends*/  
 return EXIT_SUCCESS;
}