#include "types.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
struct rtcdate r;

if (date(&r)) 
{
  printf(2, "date failed\n");
  exit();
}

//Printing Date in the given format
//Print year
printf(2,"Year: %d\n",r.year);
//Print Month
     if(r.month == 1){printf(2,"Month: January\n");}
else if(r.month == 2){printf(2,"Month: February\n");}
else if(r.month == 3){printf(2,"Month: March\n");}
else if(r.month == 4){printf(2,"Month: April\n");}
else if(r.month == 5){printf(2,"Month: May\n");}
else if(r.month == 6){printf(2,"Month: June\n");}
else if(r.month == 7){printf(2,"Month: July\n");}
else if(r.month == 8){printf(2,"Month: August\n");}
else if(r.month == 9){printf(2,"Month: September\n");}
else if(r.month == 10){printf(2,"Month: October\n");}
else if(r.month == 11){printf(2,"Month: November\n");}
else if(r.month == 12){printf(2,"Month: December\n");}
//Print Date
printf(2,"Date: %d\n",r.day);
// Print time
// The time is obtained in GMT for Indian time GMT + 5:30
if(r.minute + 30 < 60)
{
  printf(2,"Hour: %d\n",r.hour + 5); 
  printf(2,"Minute: %d\n",r.minute + 30);
}
else
{
  printf(2,"Hour: %d\n",r.hour + 6); 
  printf(2,"Minute: %d\n",(r.minute + 30)%60);
}
printf(2,"Second: %d\n",r.second);

exit();
}