#include <iostream>
#include "auction.h"

int main()
{

  std::cout<<"Welcome to Auction"<<std::endl;


    return 0;
}