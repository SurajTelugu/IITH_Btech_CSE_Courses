#include "stdafx.h"

/// No code required 
/// Just initialized all headers in one standard header 